from .maze import Maze


class PathAnalyzer:
    """Analyze routes between the maze entry and exit."""

    def __init__(self, maze: Maze) -> None:
        """Initialize the path analyzer.

        Args:
            maze: Maze structure to analyze.
        """
        self.maze = maze

    def _path_exists_without_edge(
        self,
        blocked_edge: frozenset[tuple[int, int]] | None = None,
    ) -> bool:
        """Check whether a path exists without using a specific edge.

        Args:
            blocked_edge: Optional edge that cannot be used.

        Returns:
            True if the exit remains reachable from the entry.
        """
        if self.maze.entry is None:
            return False
        if self.maze.exit is None:
            return False

        start = self.maze.entry
        target = self.maze.exit
        queue: list[tuple[int, int]] = [start]
        visited: set[tuple[int, int]] = {start}

        while queue:
            x, y = queue.pop(0)
            if (x, y) == target:
                return True

            cell = self.maze.get_cell(x, y)
            neighbors = self.maze.get_neighbors(cell)

            for direction, neighbor in neighbors.items():
                if neighbor.blocked:
                    continue
                if not self.maze.can_move(
                    cell,
                    direction,
                ):
                    continue

                current_edge = frozenset(
                    {
                        (x, y),
                        (neighbor.x, neighbor.y),
                    }
                )
                if current_edge == blocked_edge:
                    continue

                position = (
                    neighbor.x,
                    neighbor.y,
                )
                if position in visited:
                    continue

                visited.add(position)
                queue.append(position)

        return False

    def _find_entry_exit_path(
        self,
    ) -> list[tuple[int, int]]:
        """Find one path between the maze entry and exit.

        Returns:
            Ordered positions forming an entry-to-exit path.
        """
        if self.maze.entry is None:
            return []
        if self.maze.exit is None:
            return []

        start = self.maze.entry
        target = self.maze.exit
        queue: list[tuple[int, int]] = [start]
        previous: dict[
            tuple[int, int],
            tuple[int, int] | None,
        ] = {start: None}

        while queue:
            x, y = queue.pop(0)
            if (x, y) == target:
                break

            cell = self.maze.get_cell(x, y)
            neighbors = self.maze.get_neighbors(cell)

            for direction, neighbor in neighbors.items():
                if neighbor.blocked:
                    continue
                if not self.maze.can_move(
                    cell,
                    direction,
                ):
                    continue

                position = (
                    neighbor.x,
                    neighbor.y,
                )
                if position in previous:
                    continue

                previous[position] = (x, y)
                queue.append(position)

        if target not in previous:
            return []

        path: list[tuple[int, int]] = []
        current: tuple[int, int] | None = target

        while current is not None:
            path.append(current)
            current = previous[current]

        path.reverse()
        return path

    def has_alternative_entry_exit_route(
        self,
    ) -> bool:
        """Check whether the entry and exit have an alternative route.

        Returns:
            True if removing any edge of one path still leaves a route.
        """
        path = self._find_entry_exit_path()
        if len(path) < 2:
            return False

        for index in range(len(path) - 1):
            first = path[index]
            second = path[index + 1]
            blocked_edge = frozenset(
                {
                    first,
                    second,
                }
            )

            if not self._path_exists_without_edge(
                blocked_edge
            ):
                return False

        return True
